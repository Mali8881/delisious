import 'package:flutter/material.dart';
import '../../../../data/models/product_model.dart';

class OrderProvider extends ChangeNotifier {
  final List<Map<String, dynamic>> _orders = [];

  List<Map<String, dynamic>> get orders => _orders;

  void createOrder(List<MapEntry<Product, int>> cartItems) {
    final total = cartItems.fold(0.0, (sum, item) => sum + item.key.price * item.value);
    final names = cartItems.map((e) => e.key.name).toList();

    _orders.insert(0, {
      'date': DateTime.now().toString().substring(0, 16),
      'items': names,
      'total': total,
    });

    notifyListeners();
  }

  void clearOrders() {
    _orders.clear();
    notifyListeners();
  }
}
