import 'package:flutter/material.dart';
import '../../../../data/models/product_model.dart';

class CartProvider extends ChangeNotifier {
  final Map<Product, int> _items = {};

  Map<Product, int> get items => _items;

  double get totalPrice => _items.entries
      .map((e) => e.key.price * e.value)
      .fold(0.0, (prev, curr) => prev + curr);

  void addToCart(Product product) {
    _items.update(product, (qty) => qty + 1, ifAbsent: () => 1);
    notifyListeners();
  }

  void removeFromCart(Product product) {
    if (_items.containsKey(product)) {
      _items.remove(product);
      notifyListeners();
    }
  }

  void clearCart() {
    _items.clear();
    notifyListeners();
  }

  void changeQuantity(Product product, int qty) {
    if (qty <= 0) {
      _items.remove(product);
    } else {
      _items[product] = qty;
    }
    notifyListeners();
  }
}
