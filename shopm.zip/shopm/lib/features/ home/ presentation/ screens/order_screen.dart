import 'package:flutter/material.dart';

class OrderScreen extends StatelessWidget {
  const OrderScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, dynamic>> orders = [
      {
        'date': '21 мая 2025',
        'total': 980.0,
        'items': ['Котлеты с пюре', 'Тирамису'],
      },
      {
        'date': '19 мая 2025',
        'total': 1340.0,
        'items': ['Паста Карбонара', 'Морс ягодный', 'Цезарь'],
      },
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Мои заказы')),
      body: ListView.builder(
        itemCount: orders.length,
        padding: const EdgeInsets.all(16),
        itemBuilder: (context, index) {
          final order = orders[index];
          final date = order['date'] as String;
          final total = order['total'] as double;
          final items = order['items'] as List<String>;

          return Card(
            margin: const EdgeInsets.only(bottom: 16),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(date, style: const TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 4),
                  Text('Состав: ${items.join(', ')}'),
                  const SizedBox(height: 8),
                  Text('Итого: ${total.toStringAsFixed(1)} ₽',
                      style: const TextStyle(fontWeight: FontWeight.bold)),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
