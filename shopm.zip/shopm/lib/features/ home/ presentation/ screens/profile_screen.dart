import 'package:flutter/material.dart';
import 'edit_profile_screen.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Профиль')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const CircleAvatar(
            radius: 40,
            backgroundImage: NetworkImage('https://i.imgur.com/fbYqD0z.png'),
          ),
          const SizedBox(height: 12),
          const Center(
            child: Text(
              'Айбек Маматов',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
            ),
          ),
          const SizedBox(height: 4),
          const Center(
            child: Text('example@gmail.com', style: TextStyle(color: Colors.grey)),
          ),
          const SizedBox(height: 24),
          const Divider(),

          ListTile(
            leading: const Icon(Icons.edit),
            title: const Text('Редактировать профиль'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () async {
              final result = await Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const EditProfileScreen(
                    name: 'Айбек Маматов',
                    phone: '+996 700 123 456',
                    address: 'г. Бишкек, ул. Исанова, 12',
                  ),
                ),
              );
              if (result != null) {
                // здесь можно сохранить в provider или локальную переменную
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Профиль обновлён')),
                );
              }
            },
          ),

          ListTile(
            leading: const Icon(Icons.location_on),
            title: const Text('Адрес доставки'),
            subtitle: const Text('г. Бишкек, ул. Исанова, 12'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () {
              // Отдельный экран или можно использовать EditProfileScreen с фокусом на адрес
            },
          ),

          ListTile(
            leading: const Icon(Icons.phone),
            title: const Text('Номер телефона'),
            subtitle: const Text('+996 700 123 456'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () {},
          ),

          ListTile(
            leading: const Icon(Icons.logout),
            title: const Text('Выйти из аккаунта'),
            onTap: () {
              // TODO: обработка выхода
            },
          ),
        ],
      ),
    );
  }
}
